module.exports = {
   'serverUrl': 'http://localhost:3001',
   'serverUrl3000': 'http://localhost:3000',
   'rtmpUrl': 'rtmp://url:1935/liveshow/citest',
   'rtspUrl': 'rtsp://admin:admin@url/ip:554/cam/realmonitor?channel=1&subtype=0&unicast=true&proto=Onvif',
   "sipServer": "url/ip",
   "username": "user1",
   "username2": "user2",
   "password": "123",
   'authorization': 'MAuth realm=http://marte3.dit.upm.es,mauth_signature_method=HMAC_SHA256,mauth_serviceid=5cb3e6e69ea30e73d1235c73,mauth_cnonce=2a2e556bb82f2d52,mauth_timestamp=1555384255816,mauth_signature=NWJiODJlOTk3Yzg4MzkxMzI4ODZhYzZmMzRlZGQ1ODE2ZWQ0ZmZlMjI2MzQ4MmE3ZDY1YjgxZTMzYTA0MzFlMQ=='
}
